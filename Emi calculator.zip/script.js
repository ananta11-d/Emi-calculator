$(document).ready(function() {
    let chart = null; // Initialize chart variable

    $('#calculateBtn').on('click', function(event) {
        event.preventDefault(); // Prevent default form submission behavior

        const principal = parseFloat($('#principal').val());
        const time = parseInt($('#time').val());
        const emiType = $('#emiType').val();
        const interestRate = parseFloat($('#interestRate').val()) / 100;
        const startDate = new Date($('#startDate').val());

        const emiAmount = calculateEMI(principal, time, emiType, interestRate);
        const totalAmount = emiAmount * time * getFrequencyMultiplier(emiType);

        const chartData = [
            { label: 'Principal Amount', value: principal },
            { label: 'Interest Amount', value: totalAmount - principal }
        ];

        if (chart) {
            // Update existing chart data
            chart.data.labels = chartData.map(item => item.label);
            chart.data.datasets[0].data = chartData.map(item => item.value);
            chart.update(); // Update chart
        } else {
            // Render new chart
            renderPieChart(chartData);
        }

        $('#viewDetailsBtn').show();
    });
    $('#viewDetailsBtn').on('click', function() {
        $('#details').empty();

        const principal = parseFloat($('#principal').val());
        const time = parseInt($('#time').val());
        const emiType = $('#emiType').val();
        const interestRate = parseFloat($('#interestRate').val()) / 100;
        const startDate = new Date($('#startDate').val());

        const details = $('#details');
        const table = $('<table>').addClass('table').append(`<thead>
                                <tr>
                                    <th scope="col">Date</th>
                                    <th scope="col">EMI Amount</th>
                                    <th scope="col">Interest</th>
                                    <th scope="col">Principal</th>
                                    <th scope="col">Total Amount</th>
                                </tr>
                            </thead>`);

        let currentDate = new Date(startDate);
        for (let i = 1; i <= time * getFrequencyMultiplier(emiType); i++) {
            const interest = (principal * interestRate) / getFrequencyMultiplier(emiType);
            const principalPayment = emiAmount - interest;
            principal -= principalPayment;

            table.append(`<tr>
                                    <td>${currentDate.toLocaleDateString('en-IN')}</td>
                                    <td>Rs. ${emiAmount.toFixed(2)}</td>
                                    <td>Rs. ${interest.toFixed(2)}</td>
                                    <td>Rs. ${principal.toFixed(2)}</td>
                                    <td>Rs. ${(emiAmount + principal).toFixed(2)}</td>
                                </tr>`);

            currentDate = addFrequency(currentDate, emiType);
        }

        details.append(table);
    });
});

function calculateEMI(principal, time, emiType, interestRate) {
    const n = time * getFrequencyMultiplier(emiType);
    const r = interestRate / getFrequencyMultiplier(emiType);
    const emi = (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    return emi;
}

function getFrequencyMultiplier(emiType) {
    switch (emiType) {
        case 'daily':
            return 365;
        case 'weekly':
            return 52;
        case 'bi-weekly':
            return 26;
        case 'monthly':
            return 12;
        default:
            return 1;
    }
}

function addFrequency(date, emiType) {
    switch (emiType) {
        case 'daily':
            return new Date(date.setDate(date.getDate() + 1));
        case 'weekly':
            return new Date(date.setDate(date.getDate() + 7));
        case 'bi-weekly':
            return new Date(date.setDate(date.getDate() + 14));
        case 'monthly':
            return new Date(date.setMonth(date.getMonth() + 1));
        default:
            return date;
    }
}

function renderPieChart(data) {
    const ctx = document.getElementById('chart').getContext('2d');
    chart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(item => item.label),
            datasets: [{
                backgroundColor: ['#FFCD20', '#27B671'],
                data: data.map(item => item.value)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}
